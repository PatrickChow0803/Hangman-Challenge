package com.lambdaschool.hangman

import org.junit.Test

import org.junit.Assert.*

class HangmanTests {
    @Test
    fun `test assertion todo`() {
        assertEquals(4, 2 + 2)
    }
}
